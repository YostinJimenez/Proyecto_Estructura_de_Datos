#include "Transaccion.h"
// Implementación vacía, ya que Transaccion es una plantilla definida completamente en Transaccion.h