#include "ListaDobleCircular.h"
// Implementación vacía, ya que ListaDobleCircular es una plantilla definida completamente en ListaDobleCircular.h