#ifndef MENU_ADMIN_H
#define MENU_ADMIN_H

void mostrarMenuAdmin();

#endif