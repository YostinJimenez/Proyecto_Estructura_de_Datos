#ifndef RECUPERAR_CUENTA_H
#define RECUPERAR_CUENTA_H

void recuperarCuenta();

#endif