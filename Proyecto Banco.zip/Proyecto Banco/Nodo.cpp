#include "Nodo.h"
// Implementación vacía, ya que Nodo es una plantilla definida completamente en Nodo.h