// recuperarCuenta.h
#ifndef RECUPERAR_CUENTA_H
#define RECUPERAR_CUENTA_H
#include "ListaDobleCircular.h"
#include "Cliente.h"

void recuperarCuenta(ListaDobleCircular<Cliente>& clientes);

#endif